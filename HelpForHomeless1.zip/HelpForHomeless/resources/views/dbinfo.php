<?php
$username="sa1022_shofiqul";
$password="blackassassin34";
$database="sa1022_MyProject1";
?>