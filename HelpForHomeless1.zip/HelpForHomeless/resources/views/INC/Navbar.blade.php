 <nav class="navbar fixed-top navbar-expand-md navbar-dark bg-dark">
 <a class="navbar-brand" href="/">{{config('', 'HFH')}}</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse">
    <ul class="nav navbar-nav navbar-center ">
      <li class=" active">
        <a class="nav-link" href="/">Home</a>
      </li>
      <li class="active">
        <a class ="nav-link" href="/about">Immediate Help</a>   
      </li>
      <li class="active">
        <a class ="nav-link" >About Us</a>
      </li>
      <li class="active">
        <a class ="nav-link" >Donate</a>
      </li>
      <li class="nav-item active">
        <a class ="nav-link" >Volunteering</a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-1 ">
    </form>
  </div>
</nav>