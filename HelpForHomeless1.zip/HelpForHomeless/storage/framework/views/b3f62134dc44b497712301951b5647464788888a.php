 <head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>

 <html>
     <head>


<?php $__env->startSection('content'); ?>

<h1><?php echo e($title); ?></h1>
     </head>
     <body>
<p> This is the Help page </p>
<p>This is the checklist which will aid you in what you need help with, please choose whichever tasks or items you
    feel you need help with. Choosing an object, it will try and match you with which items are best to for the situation 
    that you are in. The aim of this is to help you remain anonymous but also providing you with the assistance of what you
    need all in one location. This will make your process easier, by being able to find what you need, who to contact
    and what is open in one location, you are able to better spend your time helping yourself.</p>

<p>Please Tick any box that you feel you need help with. Hover over each of the images to find out what each 
    item can help you with </p>

   
<form action="/gmaps" method ="get">

   

    <nav id = "list-items" role = "navig">
     <div class ="boxes-container">
        <ul class = "boxes">
            <div class ="DoctorTab">
            <li>
                <input type="image" src="images/Food.jpg" class="img-thumbnail rounded float left" alt="yyeet" style ="width:250px; height:250px;">
                <input type="checkbox" name="food1" value="Food"> 
            </li>
            <li>
            </div>
                <input type="image" src="images/Shelter.jpg" class="img-thumbnail rounded float left" alt="yyeet" style ="width:250px; height:250px;">
                <label><input type="checkbox" value="Shelter"> Shelter </label>
            </li>
            <li>
                <input type="image" src= "images/Jobs.jpg" class="img-thumbnail rounded float left" alt="yyeet" style ="width:250px; height:250px;">
                <label><input type="checkbox" value="Jobs"> Jobs</label>
            </li> 
            <li>
                <input type="image" src="images/Doctor.jpg" class="img-thumbnail rounded float left" alt="yyeet" style ="width:250px; height:250px;">	
                <label><input type="checkbox" name="attribute" value="Doctor"> Doctor</label>
            </li>
            <li>
                <input type="image" src="images/Dentist.jpg" class="img-thumbnail rounded float left" alt="yyeet" style ="width:250px; height:250px;">
                <label><input type="checkbox" name="attribute" value="Dentist"> Dentist</label>
            </li>
            <li>
                <input type="image" src="images/DrugAbuse.jpg" class="img-thumbnail rounded float left" alt="yyeet" style ="width:250px; height:250px;">
                <label><input type="checkbox" name="attribute" value="DrugAbuse"> Drug Abuse</label>
            </li>
            <li>
                <input type="image" src="images/AlcoholAbuse.jpg" class="img-thumbnail rounded float left" alt="yyeet" style ="width:250px; height:250px;">
                <label><input type="checkbox" name="attribute" class="help-checks" value="AlcoholAbuse"> Alcohol Abuse</label>
            </li>
            <li>
                <input type="image" src="images/AsylumSeekers.jpg" class="img-thumbnail rounded float left" alt="yyeet" style ="width:250px; height:250px;">
                <label><input type ="checkbox" name="attribute" class="help-checks" value="AsylumSeekers">Asylum Seekers</label>
            </li>
            </ul>
    </div>
    <button id="one" type ="button" class=btn btn-Primary>Submit</button>
    
    <script>
        $('body').on('click', '#one', function() {
         
        var favorite = [];
            $.each($(".help-checks:checked"), function(){
                favorite.push($(this).val());
            });

        var checkedCheckbox = favorite[0];
        var allChecked = favorite.join(",");
        
        window.location.replace("gmaps?type=" + allChecked)
    });
    </script>

</form>

     </body>
 </html>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lsapp\resources\views/pages/about.blade.php ENDPATH**/ ?>