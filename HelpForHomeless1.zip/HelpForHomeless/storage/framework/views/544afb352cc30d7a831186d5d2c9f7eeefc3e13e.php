<head>
    <?php
    //header('Content-Type: application/xml; charset=utf-8');
    header('Content-Type: text/xml');
    ?>
    
</head>
<?php


$dom       = new DOMDocument("1.0");
$node      = $dom->createElement("markers");
$parnode   = $dom->appendChild($node);
$argument1 = "";

if ($_GET) {
    $argument1 = $_GET['type'];
}
$argument1 = "jobs";
$mysqli    = new mysqli('localhost', 'sa1022_shofiqul', 'blackassassin34', 'sa1022_MyProject1');

if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: " . $mysqli->connect_error;
    exit();
}

$sql = "";
if ($argument1 != "") {
    $sql = "SELECT id,name,address,lat,lng,type from markers WHERE type = '{$argument1}'";
}
$result = mysqli_query($mysqli, $sql);



while ($row = mysqli_fetch_row($result)) {
    
    $node    = $dom->createElement("marker");
    $newnode = $parnode->appendChild($node);
    $newnode->setAttribute("id", $row[0]);
    $newnode->setAttribute("name", $row[1]);
    $newnode->setAttribute("address", $row[2]);
    $newnode->setAttribute("lat", $row[3]);
    $newnode->setAttribute("lng", $row[4]);
    $newnode->setAttribute("type", $row[5]);
}
// Free result set
mysqli_free_result($result);

echo $dom->saveXML();

?><?php /**PATH /home/sa1022/HelpForHomeless/resources/views/services.blade.php ENDPATH**/ ?>