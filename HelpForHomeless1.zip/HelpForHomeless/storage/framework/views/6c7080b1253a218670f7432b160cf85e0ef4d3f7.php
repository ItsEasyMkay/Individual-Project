<head>
   <meta name="viewport" content="initial-scale=1.0, user-scalable=no" />
   <meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
   <title>Using MySQL and PHP with Google Maps</title>
   <script  src="https://code.jquery.com/jquery-3.5.1.js"  integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc="  crossorigin="anonymous"></script>
   <style>
      /* Always set the map height explicitly to define the size of the div
      * element that contains the map. */
      /*https://developers.google.com/maps/documentation/javascript/mysql-to-maps*/
      html, body {
      height: 100%;
      margin: 0;
      padding: 0;
      }
   </style>
   
   <?php $__env->startSection('content'); ?>
   <?php $__env->stopSection(); ?>
   <p id="demo"></p>
</head>
<html>
   <body>
      <div id="map"></div>
      <script>
         function initMap() {
         var map = new google.maps.Map(document.getElementById('map'), {
           center: new google.maps.LatLng(50.8225 , -0.1372 ),
           zoom: 14
         });
         var infoWindow = new google.maps.InfoWindow;
         
          var urlParam = getUrlParameter('type');
             var islocal = false;
             var baseurl =  islocal ? 'http://sa1022.brighton.domains/' : '';
         
             // Change this depending on the name of your PHP or XML file
             downloadUrl(baseurl + 'xmlfile?type=' + urlParam, function (data) {
             var xml = data.responseXML;
             var markers = xml.documentElement.getElementsByTagName('marker');
             Array.prototype.forEach.call(markers, function(markerElem) {
               var id = markerElem.getAttribute('id');
               var name = markerElem.getAttribute('name');
               var address = markerElem.getAttribute('address');
               var type = markerElem.getAttribute('type');
               var description = markerElem.getAttribute('description');
               var phone = markerElem.getAttribute('phone');
               var email = markerElem.getAttribute('email');
               
                $('#mapsBox').html($('#mapsBox').html() + " Name: " + name + "<br />" + " Address: " + address + "<br />" + "Description: " + description + "<br />" + "Phone: " + phone + "<br />" + "Email: " + email + "<br />" + "<br />" );
               
               var point = new google.maps.LatLng(
                   parseFloat(markerElem.getAttribute('lat')),
                   parseFloat(markerElem.getAttribute('lng')));
         
               var infowincontent = document.createElement('div');
               var strong = document.createElement('strong');
               strong.textContent = name
               infowincontent.appendChild(strong);
               infowincontent.appendChild(document.createElement('br'));
               var text = document.createElement('text');
               text.textContent = address
               infowincontent.appendChild(text);
               var marker = new google.maps.Marker({
                 map: map,
                 position: point,
                 label: ""
               });
               
               marker.addListener('click', function() {
                 infoWindow.setContent(infowincontent);
                 infoWindow.open(map, marker);
               });
             });
           });
         }
         
         
         
         function downloadUrl(url, callback) {
         var request = window.ActiveXObject ?
             new ActiveXObject('Microsoft.XMLHTTP') :
             new XMLHttpRequest;
         
         request.onreadystatechange = function() {
           if (request.readyState == 4) {
             request.onreadystatechange = doNothing;
             callback(request, request.status);
           }
         };
         
         request.open('GET', url, true);
         request.send(null);
         }
         
         function doNothing() {}
         //https://davidwalsh.name/query-string-javascript
         function getUrlParameter(name) {
             name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
             var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
             var results = regex.exec(location.search);
             return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
         
         };
      </script>
      <script defer
         src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC5OUCDWQnpEsXtUFp8tpo9La61FS3aFsk&callback=initMap"></script>
      <div class = "wrapper">
         <nav id="sidebar">
            <div class="mapsBox" id = "mapsBox" >
            </div>
         </nav>
         <div id = "content">
         </div>
      </div>
   </body>
</html>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sa1022/HelpForHomeless/resources/views/test.blade.php ENDPATH**/ ?>