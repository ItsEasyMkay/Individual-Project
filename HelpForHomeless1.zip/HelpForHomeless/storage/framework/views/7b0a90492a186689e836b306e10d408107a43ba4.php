<!DOCTYPE html>
 <head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>

 <html>
     <head>


<?php $__env->startSection('content'); ?>

    <div class = "banner1" > 
    <image src="images/Banner2.jpg" class ="bannerImage" alt="yyeet">
   </div>
   
   <div class = "bannerBox">
    <p1> Welcome to Help for Homeless, This website is designed to help you with your needs regardless of your financial situation or background. It is designed to be able to get help which is unidentifiable, free of charge and easy to access.</p1>
    
    </div>
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
   </body>
 </html>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sa1022/HelpForHomeless/resources/views/welcome.blade.php ENDPATH**/ ?>