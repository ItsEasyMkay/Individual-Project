<?php $__env->startSection('content'); ?>
<h1><?php echo e($title); ?></h1>
<p> Here you will find help on the aspects you find to be difficult, please go through the list and answer the questions accordingly, answering them correctly will yield you the best results for us to help you. </p>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lsapp\resources\views/pages/index.blade.php ENDPATH**/ ?>