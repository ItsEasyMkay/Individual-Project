<?php

//require("phpsqlajax_dbinfo.php");

// Start XML file, create parent node

$dom = new DOMDocument("1.0");

$node = $dom->createElement("markers");
$parnode = $dom->appendChild($node);
$argument1 = "";
//Opens a connection to a MySQL server
if ($_GET) {
$argument1 = $_GET['type'];
} 
$argument1 = "jobs";
//$sql="SELECT id,name,address,lat,lng,type from markers WHERE type IN (".implode(",",array_map('intval',$argument1)).")";

//Argument1 = "aslyum,food"
//split argument1 back into an array
//make sql do a where on each argument                 
                 
 //Select all the rows in the markers table

//$query = "SELECT * FROM markers WHERE 1";
//$result = mysqli_query($query);
//if (!$result) {
  //die('Invalid query: ' . mysqli_error());
  //}

$mysqli = new mysqli('localhost','sa1022_shofiqul','blackassassin34','sa1022_MyProject1');

// Check connection
if ($mysqli -> connect_errno) {
  echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
  exit();
}

$sql = "";
if($argument1 != ""){
    $sql="SELECT id,name,address,lat,lng,type from markers WHERE type = '{$argument1}'";
}
/*else if($argument1 == "sdf"){
    $sql="SELECT id,name,address,lat,lng,type from markers";
}
else if($argument1 == "sdsdfsldfmsl"){
  $sql="SELECT id,name,address,lat,lng,type from markers WHERE type IN (".implode(",",array_map('intval',$argument1)).")";
}
else{
  $sql="SELECT id,name,address,lat,lng,type from markers WHERE type IN (".implode(",",array_map('intval',$argument1)).")";
}*/
$result=mysqli_query($mysqli,$sql);

if ($result)
  {
  // Fetch one and one row
  while ($row=mysqli_fetch_row($result))
    {
  $node = $dom->createElement("marker");
  $newnode = $parnode->appendChild($node);
  $newnode->setAttribute("id",$row[0]);
  $newnode->setAttribute("name",$row[1]);
  $newnode->setAttribute("address", $row[2]);
  $newnode->setAttribute("lat", $row[3]);
  $newnode->setAttribute("lng", $row[4]);
  $newnode->setAttribute("type", $row[5]);
    }
  // Free result set
  mysqli_free_result($result);
}
header('Content-Type: text/xml');


$xml_String = $dom->saveXML();

return $xml_String;

?><?php /**PATH /home/sa1022/lsapp/resources/views/services.blade.php ENDPATH**/ ?>