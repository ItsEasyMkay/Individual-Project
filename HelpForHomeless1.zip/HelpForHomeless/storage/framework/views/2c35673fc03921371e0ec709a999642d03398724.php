<head>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
   
</head>
<html>
    <!--/*https://www.w3schools.com/howto/howto_js_image_grid.asp*/ -->
   <head>
      
      <?php $__env->startSection('content'); ?>
   </head>
   <body>
      <p>This is the checklist which will aid you in what you need help with, please choose whichever tasks or items you
         feel you need help with. Choosing an object, it will try and match you with which items are best to for the situation 
         that you are in. The aim of this is to help you remain anonymous but also providing you with the assistance of what you
         need all in one location. This will make your process easier, by being able to find what you need, who to contact
         and what is open in one location, you are able to better spend your time helping yourself.
      </p>
      <p>
         Please select from one of the following you think you need help from:
      </p>
      <form action="/xmlfile" method ="get">
         <div class="imageRow">
            <div class="imageColumn">
               <div class= "box-container">
                  <image src="images/Food.jpg" class ="box-image" alt="Food">
                  <label><input type="checkbox" name="food" value="Food"> Food </label> 
                  <div class = "middle">
                     <div class = "image-text"> Clicking this check box will take you to sites, emails and phone numbers of local foodbanks which may be able to supply you with food. </div>
                  </div>
               </div>
            </div>
            <div class="imageColumn">
               <div class= "box-container">
                  <image src="images/Shelter.jpg" class="box-image" alt="Shelter">
                  <label><input type="checkbox" name="shelter" value="Shelter"> Shelter </label>
                  <div class = "middle">
                     <div class = "image-text"> Clicking this check box will take you to sites, emails and phone numbers of local foodbanks which may be able to supply you with food. </div>
                  </div>
               </div>
            </div>
            <div class="imageColumn">
               <div class="box-container">
                  <image src= "images/Jobs.jpg" class="box-image" alt="Jobs">
                  <label><input type="checkbox" name="jobs" value="Jobs"> Jobs </label>
                  <div class = "middle">
                     <div class = "image-text"> Clicking this check box will take you to sites, emails and phone numbers of local foodbanks which may be able to supply you with food. </div>
                  </div>
               </div>
            </div>
            <div class="imageColumn">
               <div class ="box-container">
                  <image src="images/Doctor.jpg" class="box-image" alt="Doctor">
                  <label><input type="checkbox" name="doctor" value="Doctor"> Doctor </label>
                  <div class = "middle">
                     <div class = "image-text"> Clicking this check box will take you to sites, emails and phone numbers of local foodbanks which may be able to supply you with food. </div>
                  </div>
               </div>
            </div>
            <div class="imageColumn">
               <div class = "box-container">
                  <image src="images/Dentist.jpg" class="box-image" alt="Dentist" >
                  <label><input type="checkbox" name="dentist" value="Dentist"> Dentist </label>
                  <div class = "middle">
                     <div class = "image-text"> Clicking this check box will take you to sites, emails and phone numbers of local foodbanks which may be able to supply you with food. </div>
                  </div>
               </div>
            </div>
            <div class="imageColumn">
               <div class ="box-container">
                  <image src="images/DrugAbuse.jpg" class="box-image" alt="DrugAbuse" >
                  <label><input type="checkbox" name="drugAbuse" value="Drug%20Abuse"> Drug Abuse </label>
                  <div class = "middle">
                     <div class = "image-text"> Clicking this check box will take you to sites, emails and phone numbers of local foodbanks which may be able to supply you with food. </div>
                  </div>
               </div>
            </div>
            <div class="imageColumn">
               <div class ="box-container">
                  <image src="images/AlcoholAbuse.jpg" class="box-image" alt="AlcoholAbuse">
                  <label><input type="checkbox" name="alcoholAbuse" value="Alcohol%20Abuse"> Alcohol Abuse </label>
                  <div class = "middle">
                     <div class = "image-text"> Clicking this check box will take you to sites, emails and phone numbers of the local places which host AA meetings and  </div>
                  </div>
               </div>
            </div>
            <div class="imageColumn">
               <div class ="box-container">
                  <image src="images/AsylumSeekers.jpg" class="box-image" alt="AsylumSeekers">
                  <input type="checkbox" name="alcoholAbuse" value="Asylum%20Seekers"> Asylum Seeker </label>
                  <div class = "middle">
                     <div class = "image-text"> Clicking this check box will take you to sites, emails and phone numbers of the local places which host AA meetings and  </div>
                  </div>
               </div>
            </div>
         </div>
         <button id="one" type ="button" class=btn btn-Primary>Submit</button>
         <script>
            $('body').on('click', '#one', function() {
            var favorite = [];
                $.each($('input:checkbox:checked'), function(){
                    favorite.push($(this).val());
                });
            
            var checkedCheckbox = favorite[0];
            var allChecked = favorite.join(",");
            
            window.location.replace("test?type=" + allChecked)
            });
         </script>
      </form>
   </body>

</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sa1022/HelpForHomeless/resources/views/about.blade.php ENDPATH**/ ?>