<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/', function () {
    return view('welcome');
});
Route::get('/about', function () {
    return view('about');
});
Route::get('/services', function () {
    return view('services');
});
Route::get('/gmaps', function () {
    return view('gmaps');
});
Route::get('/xmlF', function () {
    return view('xmlF');
});
Route::get('/xmlF2', function () {
    return view('xmlF2');
});
Route::get('/gmaps2', function () {
    return view('gmaps2');
});
Route::get('/test', function () {
    return view('test');
});

//https://developers.google.com/maps/documentation/javascript/mysql-to-maps
//https://www.whoishostingthis.com/resources/xml/
Route::get('/xmlfile', function () {
$dom       = new DOMDocument("1.0");
$node      = $dom->createElement("markers");
$parnode   = $dom->appendChild($node);
$argument1 = "";

if ($_GET) {
    $argument1 = $_GET['type'];
}

$mysqli    = new mysqli('localhost', 'sa1022_shofiqul', 'testpassword123', 'sa1022_MyProject1');

if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: " . $mysqli->connect_error;
    exit();
}

$sql = "";
if ($argument1 != "") {
    $sql = "SELECT id,name,address,lat,lng,type,description,phone,email from markers WHERE type = '{$argument1}'";
}
$result = mysqli_query($mysqli, $sql);



while ($row = mysqli_fetch_row($result)) {
    
    $node    = $dom->createElement("marker");
    $newnode = $parnode->appendChild($node);
    $newnode->setAttribute("id", $row[0]);
    $newnode->setAttribute("name", $row[1]);
    $newnode->setAttribute("address", $row[2]);
    $newnode->setAttribute("lat", $row[3]);
    $newnode->setAttribute("lng", $row[4]);
    $newnode->setAttribute("type", $row[5]);
    $newnode->setAttribute("description", $row[6]);
    $newnode->setAttribute("phone", $row[7]);
    $newnode->setAttribute("e-mail", $row[8]);
}
// Free result set
mysqli_free_result($result);

$test1 = $dom->saveXML();
    return response($test1)->header('Content-Type', 'text/xml');
});
?>